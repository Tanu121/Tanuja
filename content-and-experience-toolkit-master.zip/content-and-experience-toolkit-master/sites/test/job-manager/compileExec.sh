#!/bin/bash
su - compileagent -c "$@"